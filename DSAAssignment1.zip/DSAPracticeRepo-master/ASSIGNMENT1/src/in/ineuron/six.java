package in.ineuron;

public class six {
	public boolean duplicate(int[]nums) {
	for(int i=0;i<nums.length;i++) {
		for(int j=i+1;j<nums.length;j++) {
			if(nums[i]==nums[j]) {
				return true;
			}
		}
	}
	return false;
	}

	public static void main(String[] args) {
		 six six = new six();
		int nums[] = {1,2,3,1};
		 boolean res = six.duplicate(nums);
		 System.out.println(res);

	}

}
